//
// Created by Sarah Nix on 4/12/21.
//

#include "Board.h"

Board::Board() {
    setDefault();
}

void Board::setDefault() {
    over = false;
    pressed = false;
    toggled = false;
    ifstream inFile("boards/config.cfg");

    if (inFile.is_open()) {
        string heightTEMP;
        string widthTEMP;
        string minecountTEMP;
        getline(inFile, widthTEMP);
        getline(inFile, heightTEMP);
        getline(inFile, minecountTEMP);

        boardHeight = stoi(heightTEMP);
        boardWidth = stoi(widthTEMP);
        numMines = stoi(minecountTEMP);
    }
    width = boardWidth * 32;
    height = (boardHeight * 32) + 88;
    tileCount = boardHeight * boardWidth;
    countMines = numMines;

    tiles = vector<Tile> (tileCount);
    placeMines();
    connectTiles();
    for (int i = 0; i < tileCount; i++) {
        tiles.at(i).setNum();
    }
    if (toggled) {
        toggleMines();
    }
    number = 0;
    face.setTexture(TextureManager::GetTexture("face_happy"));
    debug.setTexture(TextureManager::GetTexture("debug"));
    test1.setTexture(TextureManager::GetTexture("test_1"));
    test2.setTexture(TextureManager::GetTexture("test_2"));
    test3.setTexture(TextureManager::GetTexture("test_3"));
    digit.setTexture(TextureManager::GetTexture("digits"));
}

void Board::Draw(sf::RenderWindow& window) {
    int n = 0;
    for (int i = 0; i < boardHeight; i++) {
        for (int j = 0; j < boardWidth; j++) {
            tiles.at(n).setPosition(j * 32, i * 32);
            tiles.at(n).Draw(window);
            n++;
        }
    }
    face.setPosition(((float) width/2) - 32, (float) height - 88);
    window.draw(face);
    test3.setPosition(((float) width/2) + 288, (float) height - 88);
    window.draw(test3);
    test2.setPosition(((float) width/2) + 224, (float) height - 88);
    window.draw(test2);
    test1.setPosition(((float) width/2) + 160, (float) height - 88);
    window.draw(test1);
    debug.setPosition(((float) width/2) + 96, (float) height - 88);
    window.draw(debug);
    digit.setPosition((float) 10, (float) height - 88);
    counterBoy(window);
}

void Board::readBoard(string filename) {
    over = false;
    randomNums.clear();
    tiles.clear();
    ifstream inFile(filename);
    string boom;
    int rows = 0;
    int columns = 0;
    int spot = 0;
    int i = 0;
    int size;
    numMines = 0;
    size_t found = 0;
    while (getline(inFile, boom)) {

        columns = boom.length();
        size = boom.length();
        if (boom.find("\r") != std::string::npos || boom.find("\n") != std::string::npos) {
            size --;
            columns--;
        }
        if (boom.find("1") != std::string::npos) {
            while (size > 0) {
                if (size == columns) {
                    found = boom.find("1", 0);
                }
                else {
                    found = boom.find("1", found + 1);
                }
                if (found != std::string::npos) {
                    spot += found;
                    randomNums.push_back(spot);
                }
                spot = i;
                size--;
            }
        }
        i += columns;
        spot = i;
        rows++;
    }

    boardWidth = columns;
    boardHeight = rows;
    width = boardWidth * 32;
    height = (boardHeight * 32) + 88;
    tileCount = boardHeight * boardWidth;

    tiles = vector<Tile> (tileCount);
    int n;
    for (int j = 0; j < tileCount; j++) {
        for (int k = 0; k < randomNums.size(); k++) {
            n = randomNums.at(k);
            if (j==n) {
                if (!tiles.at(j).isMine) {
                    tiles.at(j).placeMine();
                    numMines++;
                }
            }
        }
    }
    countMines = numMines;
    connectTiles();
    for (int k = 0; k < tileCount; k++) {
        tiles.at(k).setNum();
    }
    if (toggled) {
        toggleMines();
    }
    face.setTexture(TextureManager::GetTexture("face_happy"));
    debug.setTexture(TextureManager::GetTexture("debug"));
    test1.setTexture(TextureManager::GetTexture("test_1"));
    test2.setTexture(TextureManager::GetTexture("test_2"));
    test3.setTexture(TextureManager::GetTexture("test_3"));
    digit.setTexture(TextureManager::GetTexture("digits"));

    if (!pressed) {
        for (int i = 0; i < tileCount; i++) {
            getTiles().at(i).seeMine = false;
        }
    }
}

void Board::counterBoy(sf::RenderWindow& window) {

    string temp = to_string(countMines);
    int y = 0;
    int num = 0;
    if (temp.find("-") != std::string::npos) {
        num = 4;
    }
    else {
        num = 3;
    }
    vector<int> nums (num);

    if (countMines > 99 || countMines < -99) {

        if (countMines < 0) {
            for (int i = nums.size() - 1; i >= 0; i--) {
                if (temp.find("-") != std::string::npos) {
                    nums.at(0) = 10;
                }
                if (temp.at(i) == '0') {
                    nums.at(i) = 0;
                }
                if (temp.at(i) == '1') {
                    nums.at(i) = 1;
                }
                if (temp.at(i) == '2') {
                    nums.at(i) = 2;
                }
                if (temp.at(i) == '3') {
                    nums.at(i) = 3;
                }
                if (temp.at(i) == '4') {
                    nums.at(i) = 4;
                }
                if (temp.at(i) == '5') {
                    nums.at(i) = 5;
                }
                if (temp.at(i) == '6') {
                    nums.at(i) = 6;
                }
                if (temp.at(i) == '7') {
                    nums.at(i) = 7;
                }
                if (temp.at(i) == '8') {
                    nums.at(i) = 8;
                }
                if (temp.at(i) == '9') {
                    nums.at(i) = 9;
                }
            }
        }
        else {
            for (int i = nums.size() - 1; i >= 0; i--) {
                if (temp.find("-") != std::string::npos) {
                    nums.at(0) = 10;
                }
                if (temp.at(i) == '0') {
                    nums.at(i) = 0;
                }
                if (temp.at(i) == '1') {
                    nums.at(i) = 1;
                }
                if (temp.at(i) == '2') {
                    nums.at(i) = 2;
                }
                if (temp.at(i) == '3') {
                    nums.at(i) = 3;
                }
                if (temp.at(i) == '4') {
                    nums.at(i) = 4;
                }
                if (temp.at(i) == '5') {
                    nums.at(i) = 5;
                }
                if (temp.at(i) == '6') {
                    nums.at(i) = 6;
                }
                if (temp.at(i) == '7') {
                    nums.at(i) = 7;
                }
                if (temp.at(i) == '8') {
                    nums.at(i) = 8;
                }
                if (temp.at(i) == '9') {
                    nums.at(i) = 9;
                }
            }
        }
    }
    else if (((countMines < 10) && (countMines > 0)) || ((countMines > -10) && (countMines < 0)) || (countMines == 0)) {
        if (countMines < 0) {
            if (temp.find("-") != std::string::npos) {
                nums.at(0) = 10;
            }
            if (temp.at(1) == '0') {
                nums.at(3) = 0;
            }
            if (temp.at(1) == '1') {
                nums.at(3) = 1;
            }
            if (temp.at(1) == '2') {
                nums.at(3) = 2;
            }
            if (temp.at(1) == '3') {
                nums.at(3) = 3;
            }
            if (temp.at(1) == '4') {
                nums.at(3) = 4;
            }
            if (temp.at(1) == '5') {
                nums.at(3) = 5;
            }
            if (temp.at(1) == '6') {
                nums.at(3) = 6;
            }
            if (temp.at(1) == '7') {
                nums.at(3) = 7;
            }
            if (temp.at(1) == '8') {
                nums.at(3) = 8;
            }
            if (temp.at(1) == '9') {
                nums.at(3) = 9;
            }
        }
        else {
            if (temp.find("-") != std::string::npos) {
                nums[0] = 10;
            }
            if (temp == "0") {
                nums.at(nums.size() - 1) = 0;
            }
            if (temp == "1") {
                nums.at(nums.size() - 1) = 1;
            }
            if (temp == "2") {
                nums.at(nums.size() - 1) = 2;
            }
            if (temp == "3") {
                nums.at(nums.size() - 1) = 3;
            }
            if (temp == "4") {
                nums.at(nums.size() - 1) = 4;
            }
            if (temp == "5") {
                nums.at(nums.size() - 1) = 5;
            }
            if (temp == "6") {
                nums.at(nums.size() - 1) = 6;
            }
            if (temp == "7") {
                nums.at(nums.size() - 1) = 7;
            }
            if (temp == "8") {
                nums.at(nums.size() - 1) = 8;
            }
            if (temp == "9") {
                nums.at(nums.size() - 1) = 9;
            }
        }

    }
    else {

        if (countMines < 0) {
            for (int i = nums.size() - 1; i > 0; i--) {
                if (temp.find("-") != std::string::npos) {
                    nums.at(0) = 10;
                }
                if (temp.at(i - 1) == '0') {
                    nums.at(i) = 0;
                }
                if (temp.at(i - 1) == '1') {
                    nums.at(i) = 1;
                }
                if (temp.at(i - 1) == '2') {
                    nums.at(i) = 2;
                }
                if (temp.at(i - 1) == '3') {
                    nums.at(i) = 3;
                }
                if (temp.at(i - 1) == '4') {
                    nums.at(i) = 4;
                }
                if (temp.at(i - 1) == '5') {
                    nums.at(i) = 5;
                }
                if (temp.at(i - 1) == '6') {
                    nums.at(i) = 6;
                }
                if (temp.at(i - 1) == '7') {
                    nums.at(i) = 7;
                }
                if (temp.at(i - 1) == '8') {
                    nums.at(i) = 8;
                }
                if (temp.at(i - 1) == '9') {
                    nums.at(i) = 9;
                }
            }
        }
        else {
            for (int i = nums.size() - 1; i > 0; i--) {
                if (temp.find("-") != std::string::npos) {
                    nums.at(i) = 10;
                }
                if (temp.at(i - 1) == '0') {
                    nums.at(i) = 0;
                }
                if (temp.at(i - 1) == '1') {
                    nums.at(i) = 1;
                }
                if (temp.at(i - 1) == '2') {
                    nums.at(i) = 2;
                }
                if (temp.at(i - 1) == '3') {
                    nums.at(i) = 3;
                }
                if (temp.at(i - 1) == '4') {
                    nums.at(i) = 4;
                }
                if (temp.at(i - 1) == '5') {
                    nums.at(i) = 5;
                }
                if (temp.at(i - 1) == '6') {
                    nums.at(i) = 6;
                }
                if (temp.at(i - 1) == '7') {
                    nums.at(i) = 7;
                }
                if (temp.at(i - 1) == '8') {
                    nums.at(i) = 8;
                }
                if (temp.at(i - 1) == '9') {
                    nums.at(i) = 9;
                }
            }
        }
    }

    zero.loadFromFile("images/digits.png", sf::IntRect(0, 0, 21, 32));
    one.loadFromFile("images/digits.png", sf::IntRect(21, 0, 21, 32));
    two.loadFromFile("images/digits.png", sf::IntRect(42, 0, 21, 32));
    three.loadFromFile("images/digits.png", sf::IntRect(63, 0, 21, 32));
    four.loadFromFile("images/digits.png", sf::IntRect(84, 0, 21, 32));
    five.loadFromFile("images/digits.png", sf::IntRect(105, 0, 21, 32));
    six.loadFromFile("images/digits.png", sf::IntRect(126, 0, 21, 32));
    seven.loadFromFile("images/digits.png", sf::IntRect(147, 0, 21, 32));
    eight.loadFromFile("images/digits.png", sf::IntRect(168, 0, 21, 32));
    nine.loadFromFile("images/digits.png", sf::IntRect(189, 0, 21, 32));
    ten.loadFromFile("images/digits.png", sf::IntRect(210, 0, 21, 32));

    sf::Sprite zeros(zero);
    sf::Sprite ones(one);
    sf::Sprite twos(two);
    sf::Sprite threes(three);
    sf::Sprite fours(four);
    sf::Sprite fives(five);
    sf::Sprite sixs(six);
    sf::Sprite sevens(seven);
    sf::Sprite eights(eight);
    sf::Sprite nines(nine);
    sf::Sprite tens(ten);

    int n = 0;
    for (int i = 0; i < nums.size(); i++) {
        if (nums.at(i) == 0) {
            zeros.setPosition((float) 10 + n, (float) height - 88);
            window.draw(zeros);
        }
        if (nums.at(i) == 1) {

            ones.setPosition((float) 10 + n, (float) height - 88);
            window.draw(ones);
        }
        if (nums.at(i) == 2) {
            twos.setPosition((float) 10 + n, (float) height - 88);
            window.draw(twos);
        }
        if (nums.at(i) == 3) {
            threes.setPosition((float) 10 + n, (float) height - 88);
            window.draw(threes);
        }
        if (nums.at(i) == 4) {
            fours.setPosition((float) 10 + n, (float) height - 88);
            window.draw(fours);
        }
        if (nums.at(i) == 5) {
            fives.setPosition((float) 10 + n, (float) height - 88);
            window.draw(fives);
        }
        if (nums.at(i) == 6) {
            sixs.setPosition((float) 10 + n, (float) height - 88);
            window.draw(sixs);
        }
        if (nums.at(i) == 7) {
            sevens.setPosition((float) 10 + n, (float) height - 88);
            window.draw(sevens);
        }
        if (nums.at(i) == 8) {
            eights.setPosition((float) 10 + n, (float) height - 88);
            window.draw(eights);
        }
        if (nums.at(i) == 9) {
            nines.setPosition((float) 10 + n, (float) height - 88);
            window.draw(nines);
        }
        if (nums.at(i) == 10) {
            tens.setPosition((float) 10 + n, (float) height - 88);
            window.draw(tens);
        }
        n += 21;
    }
}



vector<Tile>& Board::getTiles() {
    return tiles;
}

void Board::connectTiles() {
    for (int i = 0; i < tileCount; i++) {

        // for reference: index meanings visually
        /*
         * 0. TOP
         * 1. BOTTOM
         * 2. LEFT
         * 3. RIGHT
         * 4. TOP LEFT
         * 5. TOP RIGHT
         * 6. BOTTOM LEFT
         * 7. BOTTOM RIGHT
         */

        if (i < boardWidth) {
            //TOP ROW
            if (i == 0) {
                //TOP LEFT CORNER
                tiles[i].buddies[1] = &tiles[i + boardWidth];
                tiles[i].buddies[3] = &tiles[i + 1];
                tiles[i].buddies[7] = &tiles[(i + boardWidth) + 1];
            }
            else if (i == (boardWidth - 1)) {
                //TOP RIGHT CORNER
                tiles[i].buddies[1] = &tiles[i + boardWidth];
                tiles[i].buddies[2] = &tiles[i - 1];
                tiles[i].buddies[6] = &tiles[(i + boardWidth) - 1];
            }
            else {
                //CENTER TOP
                tiles[i].buddies[1] = &tiles[i + boardWidth];
                tiles[i].buddies[2] = &tiles[i - 1];
                tiles[i].buddies[3] = &tiles[i + 1];
                tiles[i].buddies[6] = &tiles[(i + boardWidth) - 1];
                tiles[i].buddies[7] = &tiles[(i + boardWidth) + 1];
            }
        }
        else if (i >= (tileCount - boardWidth)) {
            //BOTTOM ROW
            if (i == (tileCount - boardWidth)) {
                //BOTTOM LEFT
                tiles[i].buddies[0] = &tiles[i - boardWidth];
                tiles[i].buddies[3] = &tiles[i + 1];
                tiles[i].buddies[5] = &tiles[(i - boardWidth) + 1];
            }
            else if (i == (tileCount - 1)) {
                //BOTTOM RIGHT
                tiles[i].buddies[0] = &tiles[i - boardWidth];
                tiles[i].buddies[2] = &tiles[i - 1];
                tiles[i].buddies[4] = &tiles[(i - boardWidth) - 1];
            }
            else {
                //CENTER BOTTOM
                tiles[i].buddies[0] = &tiles[i - boardWidth];
                tiles[i].buddies[2] = &tiles[i - 1];
                tiles[i].buddies[3] = &tiles[i + 1];
                tiles[i].buddies[4] = &tiles[(i - boardWidth) - 1];
                tiles[i].buddies[5] = &tiles[(i - boardWidth) + 1];
            }
        }
        else if (i % boardWidth == 0) {
            //LEFT SIDE
            tiles[i].buddies[0] = &tiles[i - boardWidth];
            tiles[i].buddies[1] = &tiles[i + boardWidth];
            tiles[i].buddies[3] = &tiles[i + 1];
            tiles[i].buddies[5] = &tiles[(i - boardWidth) + 1];
            tiles[i].buddies[7] = &tiles[(i + boardWidth) + 1];
        }
        else if (i % boardWidth == (boardWidth - 1)) {
            //RIGHT SIDE
            tiles[i].buddies[0] = &tiles[i - boardWidth];
            tiles[i].buddies[1] = &tiles[i + boardWidth];
            tiles[i].buddies[2] = &tiles[i - 1];
            tiles[i].buddies[4] = &tiles[(i - boardWidth) - 1];
            tiles[i].buddies[6] = &tiles[(i + boardWidth) - 1];
        }
        else {
            //CENTER PIECES
            tiles[i].buddies[0] = &tiles[i - boardWidth];
            tiles[i].buddies[1] = &tiles[i + boardWidth];
            tiles[i].buddies[2] = &tiles[i - 1];
            tiles[i].buddies[3] = &tiles[i + 1];
            tiles[i].buddies[4] = &tiles[(i - boardWidth) - 1];
            tiles[i].buddies[5] = &tiles[(i - boardWidth) + 1];
            tiles[i].buddies[6] = &tiles[(i + boardWidth) - 1];
            tiles[i].buddies[7] = &tiles[(i + boardWidth) + 1];
        }
    }
}

void Board::placeMines() {

    for (int k = 0; k < numMines; ) {
        int x = Random::Int(0, tileCount - 1);
        if (!tiles[x].isMine) {
            tiles[x].placeMine();
            k++;
        }
    }
}

void Board::revealMines() {
    if (over) {
        for (int i = 0; i < tileCount; i++) {
            if (tiles[i].isMine) {
                tiles[i].isClicked = true;
            }
        }
    }
    else {
        for (int i = 0; i < tileCount; i++) {
            tiles[i].revealMine();
        }
    }
}

void Board::toggleMines() {
    for (int i = 0; i < tileCount; i++) {
        tiles[i].toggleMine();
    }
    toggled = true;
}



void Board::lost() {
    over = true;
    face.setTexture(TextureManager::GetTexture("face_lose"));
    revealMines();
}

void Board::win() {
    over = true;
    face.setTexture(TextureManager::GetTexture("face_win"));
    for (int i = 0; i < tileCount; i++) {
        if (tiles[i].isMine) {
            tiles[i].flagMine();
        }
    }
    countMines = 0;
}

void Board::reset() {
    tiles.clear();
    randomNums.clear();
    setDefault();
}