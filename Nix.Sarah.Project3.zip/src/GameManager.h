//
// Created by Sarah Nix on 4/12/21.
//

#pragma once
#include "Board.h"

class GameManager {

    Board board;

public:
    void run();

};