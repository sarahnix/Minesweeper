//
// Created by Sarah Nix on 4/12/21.
//

#pragma once
#include <random>

class Random {

    static std::mt19937 random;

public:
    //one and only one instance of this thing (function etc)
    //can only access static variables inside this function
    static int Int(int min, int max);
    static float Float(float min, float max);
};