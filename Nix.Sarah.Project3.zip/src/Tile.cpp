//
// Created by Sarah Nix on 4/12/21.
//

#include "Tile.h"


Tile::Tile() {
    for (int i = 0; i < 8; i++) {
        buddies.push_back(nullptr);
    }
    isClicked = false;
    isFlag = false;
    isMine = false;
    cursed = false;
    seeMine = false;
}

void Tile::Draw(sf::RenderWindow& window) {
    string path = "number_";
    if (isClicked) {
        back.setTexture(TextureManager::GetTexture("tile_revealed"));
        window.draw(back);
        if (isMine && isFlag) {
            extra.setTexture(TextureManager::GetTexture("flag"));
            window.draw(extra);
            front.setTexture(TextureManager::GetTexture("mine"));
            window.draw(front);
        }
        else if (isMine) {
            front.setTexture(TextureManager::GetTexture("mine"));
            window.draw(front);
        }
        else {
            if (buddyMines > 0) {
                path += to_string(buddyMines);
                front.setTexture(TextureManager::GetTexture(path));
                window.draw(front);
            }
        }
    }
    else {
        back.setTexture(TextureManager::GetTexture("tile_hidden"));
        window.draw(back);

        if (isFlag) {
            front.setTexture(TextureManager::GetTexture("flag"));
            window.draw(front);
        }
        if (seeMine) {
            front.setTexture(TextureManager::GetTexture("mine"));
            window.draw(front);
        }
    }
}

void Tile::setPosition(int x, int y) {
    back.setPosition((float)x, (float)y);
    front.setPosition((float)x, (float)y);
    extra.setPosition((float)x, (float)y);
}

void Tile::setNum() {
    buddyMines = 0;
    for (int i = 0; i < buddies.size(); i++) {
        if (buddies[i] != nullptr) {
            if (buddies[i]->isMine) {
                buddyMines++;
            }
        }
    }
}



void Tile::revealTile() {
    if (!isFlag && !isClicked) {
        if ((buddyMines == 0) && !cursed && !isClicked && !isMine) {
            cursed = true;
            for (int i = 0; i < buddies.size(); i++) {
                if (buddies[i] != nullptr) {
                    buddies[i]->revealTile();
                }
            }
        }
        isClicked = true;
    }
}

void Tile::revealMine() {
    if (isMine) {
        seeMine = true;
    }
}



void Tile::flagIt() {
    if (!isClicked) {
        isFlag = true;
    }
}

void Tile::removeFlag() {
    isFlag = false;
}



void Tile::placeMine() {
    isMine = true;
}

void Tile::flagMine() {
    isFlag = true;
}

void Tile::toggleMine() {
    if (seeMine) {
        seeMine = false;
    }
    else {
        revealMine();
    }
}
