//
// Created by Sarah Nix on 4/12/21.
//

#pragma once
#include <SFML/Graphics.hpp>
#include <unordered_map>
#include <string>
using namespace std;

class TextureManager {
    //only going to be one texture object
    static unordered_map<string, sf::Texture> textures;

public:
    static void LoadTexture(string filename);
    static sf::Texture& GetTexture(string filename);
    static void Clear(); //call this once, at the end of main
};
