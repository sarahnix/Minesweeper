//
// Created by Sarah Nix on 4/12/21.
//

#pragma once
#include "Tile.h"

class Board {

private:
    vector<Tile> tiles;
    vector<int> randomNums;
    int boardHeight, boardWidth;
    sf::Texture zero, one, two, three, four, five, six, seven, eight, nine, ten;

public:
    bool toggled, pressed;
    bool over;
    int height, width, numMines, countMines, tileCount, number;
    sf::Sprite face, digit, debug, test1, test2, test3;

    //board set up
    Board();
    void setDefault();
    void Draw(sf::RenderWindow& window);
    void readBoard(string filename);
    void counterBoy(sf::RenderWindow& window);

    //mine and tile things
    vector<Tile>& getTiles();
    void connectTiles();
    void placeMines();
    void revealMines();
    void toggleMines();

    //game conditions
    void lost();
    void win();
    void reset();
};