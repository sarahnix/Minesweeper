//
// Created by Sarah Nix on 4/12/21.
//

#pragma once
#include "SFML/Graphics.hpp"
#include "TextureManager.h"
#include "Random.h"
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
using namespace std;


class Tile {

private:
    int buddyMines;

public:
    vector<Tile*> buddies;
    sf::Sprite back, front, extra;
    bool isMine, isFlag, isClicked, cursed, seeMine;

    Tile();
    void Draw(sf::RenderWindow& window);
    void setPosition(int x, int y);
    void setNum();

    void revealTile();
    void revealMine();

    void flagIt();
    void removeFlag();

    void placeMine();
    void flagMine();
    void toggleMine();
};