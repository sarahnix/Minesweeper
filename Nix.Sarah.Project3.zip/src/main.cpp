#include "GameManager.h"
using namespace std;

int main()
{
    GameManager game;
    game.run();

    return 0;
}

