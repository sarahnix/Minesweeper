//
// Created by Sarah Nix on 4/12/21.
//

#include "TextureManager.h"

unordered_map<string, sf::Texture> TextureManager::textures;

void TextureManager::LoadTexture(string name) {
    string path = "images/";
    path += name;
    path += ".png";

    textures[name].loadFromFile(path);
}

sf::Texture& TextureManager::GetTexture(string filename) {
    //if the texture does not exist
    if (textures.find(filename) == textures.end()) {
        LoadTexture(filename);
    }
    return textures[filename];
}

void TextureManager::Clear() {
    textures.clear();
}
